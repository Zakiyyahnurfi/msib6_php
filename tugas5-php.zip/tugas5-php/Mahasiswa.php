<?php
//untuk membuat class, huruf depannya harus kapital
class Mahasiswa{
//member1 - variabel 
    public $nim;
    public $nama;
    public $kuliah;
    public $matkul;
    public $nilai;
    public $grade;
    public $predikat;

//member2 (method) - constructor
public function __construct($nim, $nama, $kuliah, $matkul, $nilai){
    $this->nim = $nim;
    $this->nama = $nama;
    $this->kuliah = $kuliah;
    $this->matkul = $matkul;
    $this->nilai = $nilai;
    $this->cariGrade();
    $this->cariPredikat();
}

//member3 (method) - function return
public function getStatus(){
    if ($this->nilai>=65) return "Lulus";
    else return "Tidak Lulus";
}

//function if u/ grade dan predikat
private function cariGrade(){
    if ($this->nilai>=85){
        $this->grade = "A";
    } elseif ($this->nilai>=70){
        $this->grade = "B";
    } elseif ($this->nilai>=59){
        $this->grade = "C";
    } elseif ($this->nilai>=50){
        $this->grade = "D";
    } else{
        $this->grade = "E";
    }
}

private function cariPredikat(){
    if ($this->nilai>=85){
        $this->predikat = "Sangat Memuaskan";
    } elseif ($this->nilai>=70){
        $this->predikat = "Memuaskan";
    } elseif ($this->nilai>=59){
        $this->predikat = "Cukup";
    } elseif ($this->nilai>=50){
        $this->predikat = "Kurang";
    } else{
        $this->predikat = "Sangat Kurang";
    }
}
}
?>
