<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 5 PHP</title>
    <style>
        .form{
            margin-top: 20px;
            font-size: 15px;
        }
        th{
            font-size: 20px;
            text-align: center; 
        }
        .hasil{
            margin-top: 40px;
        }
        h1{
            text-align: center;
            font-size: 25px;
        }     
    </style>
</head>
<body>
<div class="form">
    <form action="objMahasiswa.php" method="POST" id="form">
        <table border="1" align="center" cellpadding="15" width="50%">
            <thead>
                <tr bgcolor=#f2e6ff>
                    <th colspan="2">Form Nilai Ujian</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th colspan="2"> 
                        <input type="submit" value="Kirim"> &nbsp; &nbsp; 
                    </th>
                </tr>
            </tfoot>
            <tbody>
                <tr>
                    <td>
                        <label for="nim">NIM</label>
                    </td>
                    <td>
                        <input type="text" name="nim" id="nim" placeholder="masukkan nim anda" size="50">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="nama">Nama Lengkap</label>
                    </td>
                    <td>
                        <input type="text" name="nama" id="nama" placeholder="masukkan nama anda" size="50">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="kuliah">Kuliah</label>
                    </td>
                    <td>
                        <select name="kuliah" id="kuliah">
                            <option value="">--Pilih Universitas--</option>
                            <option value="STT Nurul Fikri">STT Nurul Fikri</option>
                            <option value="Univ Sidomuncul">Univ Sidomuncul</option>
                            <option value="Univ Abepung">Univ Abepung</option>
                            <option value="STA Kerokin">STA Kerokin</option> 
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="matkul">Mata Kuliah</label>
                    </td>
                    <td>
                        <select name="matkul" id="matkul">
                            <option value="">--Mata Kuliah--</option>
                            <option value="PHP">PHP</option>
                            <option value="UI/UX">UI/UX</option>
                            <option value="JavaScript">JavaScript</option>
                            <option value="Laravel">Laravel</option> 
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="nilai">Nilai</label>
                    </td>
                    <td>
                        <input type="text" name="nilai" id="nilai" placeholder="masukkan nilai anda" size="50">
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
</div>

<?php
require_once 'Mahasiswa.php';

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $kuliah = $_POST['kuliah'];
    $matkul = $_POST['matkul'];
    $nilai = $_POST['nilai'];

    //buat objek
    $ns1 = new Mahasiswa($nim, $nama, $kuliah, $matkul, $nilai);
    $grade = $ns1->grade;
    $predikat = $ns1->predikat;

//cetak dg table
echo '<div class="hasil">';
echo '<table border="1" align="center" cellpadding="10">';
echo '<h1>Daftar Nilai Ujian Mahasiswa</h1>
<thead><tr><th>NIM</th>
<th>Nama</th><th>Kuliah</th><th>Mata Kuliah</th>
<th>Nilai</th><th>Grade</th><th>Predikat</th><th>Status</th>
</tr></thead>';
echo '<tbody>';
echo '<tr>';
echo '<td>'.$ns1->nim.'</td>';
echo '<td>'.$ns1->nama.'</td>';
echo '<td>'.$ns1->kuliah.'</td>';
echo '<td>'.$ns1->matkul.'</td>';
echo '<td>'.$ns1->nilai.'</td>';
echo '<td>'.$grade.'</td>';
echo '<td>'.$predikat.'</td>';
echo '<td>'.$ns1->getStatus().'</td>';
echo '</tr>';
echo '</tbody></table>';
echo '</div>';
}
?>
</body>
</html>
