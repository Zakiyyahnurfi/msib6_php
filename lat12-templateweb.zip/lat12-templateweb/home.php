<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="stylesheet" href="">
    <style>
        .isi {
            background-color: #ffff;
            padding: 2px;
        }
        .row {
            display: grid;
            grid-template-columns: 1fr 2fr 1fr; 
            grid-gap: 10px; 
            
        }
        .column {
            padding: 10px;
        }
        .judul {
            font-family: sans-serif; 
            font-size: 36px; 
            font-weight: bold; 
            color: #bf80ff; 
            text-align: center; 
        }
        .main-content {
            grid-column: 2; 
            justify-self: center; 

        }
    </style>
</head>
<body class="isi">
<h1 class="judul">HOME</h1>
    <div class="row">
        <div class="column side">
            <h2>Sejarah Toko..</h2>
            <p>Berdiri sejak tahun 2022 yang awalnya hanya berlokasi di Surabaya,
                kini telah melebarkan sayapnya ke 10 kota besar lainnya, seperti Malang,
                Bogor, Bandung, Tangerang, Jakarta Selatan, Depok, Medan, Pontianak, dan Aceh.
            </p>
        </div>
        <div class="column main-content">
            <h2>Pengumuman</h2>
            <p>Toko Zakiyy menjual berbagai macam kebutuhan untuk perkuliahan dengan harga terjangkau.
                Seperti laptop, wifi, meja belajar, dan ipad. Selengkapnya bisa dicek pada link berikut -> <a href="produk.php">Produk Kami</a>
            </p>
        </div>
        <div class="column side">
            <h2>Kontak Kami</h2>
            <p>Whatsapp: 08555738299<br>Instagram: @tokozakiyy<br>Tiktok: @tokozakiyy</p>
        </div>
    </div>
</body>
</html>
