<?php
//array asosiatif

//menu untuk bag atas (atas.php)
$menu_atas =[
    'home' => 'Home',
    'produk' => 'Produk',
    'pesan' => 'Cabang',
    'galeri' => 'Galeri',
    'gesbuk' => 'Gesbuk'
];

//menu untuk bag bawah (isi.php)
$menu_bawah =[
    'home' => 'home.php',
    'produk' => 'produk.php',
    'pesan' => 'pesan.php',
    'galeri' => 'galeri.php',
    'gesbuk' => 'gesbuk.php'
];
?>