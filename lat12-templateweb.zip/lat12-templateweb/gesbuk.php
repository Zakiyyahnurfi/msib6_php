<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device=width, initial=scale=1.0">
    <title>Gesbuk</title>
    <style>
        .form-container {
            margin-top: 20px; 
        }
        th {
            font-size: 24px;
            text-align: center; 
        }
    </style>
</head>

<body>
<div class="form-container">
    <form action="">
        <table border="1" align="center" cellpadding="15" width="50%">
            <thead>
                <tr bgcolor=#f2e6ff>
                    <th colspan="2">Guestbook</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th colspan="2"> 
                        <input type="submit" value="Kirim"> &nbsp; &nbsp; 
                    </th>
                </tr>
            </tfoot>
            <tbody>
                <tr>
                    <td width="25%">
                        <label for="">Nama Lengkap:</label>
                    </td>
                    <td>
                        <input type="text" name="" id="" placeholder="masukan nama anda" size="50">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">Email:</label>
                    </td>
                    <td>
                        <input type="email" name="" size="50" id="" placeholder="yourname@gmail.com">
                        <input type="hidden" name="" id="">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">Website:</label>
                    </td>
                    <td>
                        <input type="website" name="" size="50" id="" placeholder="www.yourname.com">
                        <input type="hidden" name="" id="">
                    </td>
                </tr>
                <tr>
                    <td>
                        <label for="">Pesan:</label>
                    </td>
                    <td>
                        <textarea name="" id="" cols="50" rows="5" placeholder="tinggalkan pesan anda untuk kami"></textarea>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
    </div>
</body>

</html>