<?php
//include atau include_once -> u/ potongan2 file. misalnya html nya
//require atau require_once -> pot2 file jg tapi isinya berupa kumpulan function atau class
include_once 'atas.php';
include_once 'isi.php';
include_once 'bawah.php';
?>