<div style='text-align:center; background-color: rgb(202, 177, 225); color:white;'>
        Copyright @zaki - 2024
    </div>
</body>
</html>