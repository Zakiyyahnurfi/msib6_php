<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeri</title>
    <style>
        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            display: flex;
            justify-content: space-between;
        }
        .foto {
            width: 170px; 
            margin-bottom: 20px;
            overflow: hidden; 
            border: 1px solid #a64dff;
            padding: 3px; 
        }
        .foto img {
            width: 100%;
            height: auto;
        }
        .foto:hover img {
            transform: scale(1.1); /* zoom saat hover */
        }
    </style>
</head>
<body>
    <h1 style="text-align: center; color: #bf80ff;">GALERI PRODUK</h1>
    <div class="container">
        <div class="foto">
            <img src="produk1.jpg" alt="Produk 1">
        </div>
        <div class="foto">
            <img src="produk2.jpg" alt="Produk 2">
        </div>
        <div class="foto">
            <img src="produk3.jpg" alt="Produk 3">
        </div>
        <div class="foto">
            <img src="produk4.jpg" alt="Produk 4">
        </div>
    </div>
</body>
</html>
