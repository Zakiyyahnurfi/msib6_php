<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk</title>
    <style>
        .judul {
            font-family: sans-serif; 
            font-size: 36px; 
            font-weight: bold; 
            color: #bf80ff; 
            text-align: center; 
        }
        .container {
            max-width: 800px;
            margin: auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap; 
            justify-content: space-between;
        }
        .produk {
            width: calc(50% - 10px); 
            margin-bottom: 20px;
            display: flex;
        }
        .gambar-produk {
            flex: 0 0 48%; /
            margin-right: 4%; 
        }
        .gambar-produk img {
            max-width: 100%;
            height: auto;
        }
        .deskripsi-produk {
            flex: 0 0 48%; 
        }
    </style>
</head>
<body>
    <h1 class="judul">PRODUK</h1>
    <div class="container">
        <div class="produk">
            <div class="gambar-produk">
                <img src="produk1.jpg" alt="Produk 1">
            </div>
            <div class="deskripsi-produk">
                <h2>Laptop Kuliah</h2>
                <h4>Rp 8.000.000</h4>
                <p>
                RAM 8 GB, Core i5
                </p>
            </div>
        </div>

        <div class="produk">
            <div class="gambar-produk">
                <img src="produk2.jpg" alt="Produk 2">
            </div>
            <div class="deskripsi-produk">
                <h2>WIFI</h2>
                <h4>Rp 1.000.000</h4>
                <p>
                TL-MR100, 300Mbps
                </p>
            </div>
        </div>

        <div class="produk">
            <div class="gambar-produk">
                <img src="produk3.jpg" alt="Produk 3">
            </div>
            <div class="deskripsi-produk">
                <h2>Meja Belajar</h2>
                <h4>Rp 550.000</h4>
                <p>
                Plywood A, 120 x 40 x 73
                </p>
            </div>
        </div>

        <div class="produk">
            <div class="gambar-produk">
                <img src="produk4.jpg" alt="Produk 4">
            </div>
            <div class="deskripsi-produk">
            <h2>Ipad 5</h2>
                <h4>Rp 1.700.000</h4>
                <p>
                32 GB, Wifi Only
                </p>
            </div>
        </div>
    </div>
</body>
</html>
