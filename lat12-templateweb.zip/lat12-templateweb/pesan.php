<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    .judul {
            font-family: sans-serif; 
            font-size: 36px; 
            font-weight: bold; 
            color: #bf80ff; 
            text-align: center;
    }
    </style>
</head>
<body>
<h1 class="judul">PESAN</h1>  
</body>
</html>
