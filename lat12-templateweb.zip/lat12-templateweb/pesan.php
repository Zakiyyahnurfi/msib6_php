<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DataTables</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.css">
    <style>
    .judul {
            font-family: sans-serif; 
            font-size: 36px; 
            font-weight: bold; 
            color: #bf80ff; 
            text-align: center;
    }
    </style>
</head>
<body>
<h1 class="judul">CABANG</h1>  
    <table id="example" class="display" style="width:60%">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Lokasi</th>
                <th>Kontak</th>
                <th>Instagram</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Toko Zakiyy Semarang</td>
                <td>Jl. Simongan No.129, Bongsari, Kec. Semarang Barat, Kota Semarang, Jawa Tengah 50148</td>
                <td>08374999237</td>
                <td>@tokozakiyy_smg</td>
            </tr>
            <tr>
                <td>Toko Zakiyy Medan</td>
                <td>Jl. Mahkamah No.74c, RT.02, Kec. Medan Kota, Kota Medan, Sumatera Utara 20212</td>
                <td>08836999237</td>
                <td>@tokozakiyy_mdn</td>
            </tr>
            <tr>
                <td>Toko Zakiyy Pontianak</td>
                <td>Jl. Khatulistiwa No.Kel, Batu Layang, Kec. Pontianak Utara, Kota Pontianak, Kalimantan Barat 78244</td>
                <td>08572999237</td>
                <td>@tokozakiyy_pon</td>
            </tr>
            <tr>
                <td>Toko Zakiyy Tangerang</td>
                <td>Jl. Scientia Boulevard, Curug Sangereng, Kec. Klp. Dua, Kabupaten Tangerang, Banten 15810</td>
                <td>08212999237</td>
                <td>@tokozakiyy_tgr</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th>Nama</th>
                <th>Lokasi</th>
                <th>Kontak</th>
                <th>Instagram</th>
            </tr>
        </tfoot>
    </table>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdn.datatables.net/2.0.2/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.1/js/dataTables.buttons.js"></script>
    <script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.dataTables.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
    <script>
        new DataTable('#example', {
            layout:{
                topstart: {
                    buttons : ['copy', 'csv', 'excel', 'pdf', 'print']
                }
            }
        });
    </script>
</body>
</html>