<?php
include_once 'webmenu.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Zakiyyah</title>
    <style>
        .atas {
            background-image: url('pekan1.jpeg');
            background-repeat: no-repeat;
            background-position: center;
            padding: 10px;
            background-size: cover;
            text-align: center;
            color: beige;
            padding-top: 40px;
        }
        .menu {
            text-align:center; 
            overflow: hidden;
            background-color: rgb(202, 177, 225);
            justify-content: center;
            display:flex;
            padding: 5px 8px;
        }
        .menu a {
            margin-right: 5px; 
            margin-left: 5px;
            color: #a64dff;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="atas">
        <h1>Toko Zakiyy</h1>
    </div>
    <div class="menu">
        <!-- Home | Produk | Pesan | Galeri | Gesbuk -->
        <?php
            foreach ($menu_atas as $key => $value){
                // echo "$key $value <br>";
                echo "<a href='index.php?hal=$key'> $value</a>|";
            }
        ?>
    </div>
</body>
</html>
